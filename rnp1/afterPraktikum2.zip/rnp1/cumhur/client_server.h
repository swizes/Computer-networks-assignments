/**
 * client_server.h
 *
 * author: Cumhur Guener, Jannik Iacobi
 * v0.5.1
 */

#ifndef CLIENT_SERVER_H_
#define CLIENT_SERVER_H_

#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <resolv.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <pthread.h>
#include <opencv/cv.h>
#include <opencv/highgui.h>
#include <semaphore.h>
#include <string.h>
#include <netdb.h>
#include <signal.h>

//#include <asm/atomic.h> // for atomic operations on the bufferPointer

#define MAIN_VALID_ARGC 3
#define SERVERPORT 5001
#define CLIENTSIZE 20 //3
#define ESCAPE_KEY_INT 27
#define CV_CREATE_DEFAULT_IMAGE cvCreateImage(cvSize(320, 240), IPL_DEPTH_8U, 3)
#define BUFFER_FRAME_SIZE 20
#define IMAGE_SIZE 230400
#define MAX_SOCKET_PORT_TRIES 100

int isShowImageReady;
int sockClient, sockServ;
struct in_addr server_ip;
int server_port;
//sem_t countActiveClients;
int freeServers;
int activeClientArrayPosition;
char buffer[BUFFER_FRAME_SIZE][IMAGE_SIZE];
int bufferWritePosition = 0;
int exit_server = 1;
int exit_client = 1;

pthread_mutex_t mutexBuffer = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t mutexFreeServers = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t condNewImage = PTHREAD_COND_INITIALIZER;

char* readBuffer();
void rcvServerSignal(int sig);
void showImage(void);
void* streamClient(void* arg);
void* streamServer(void* arg);
void* workingServer(void* sockfd);
void quit(char* msg, int retval);

#endif /* CLIENT_SERVER_H_ */
