/**
 * client_server.c
 *
 * author: Cumhur Guener, Jannik Iacobi
 * v0.5.1
 */

#include "client_server.h"

/**
 * main controlling code
 */
int main(int argc, char** argv) {
	pthread_t thread_c, thread_s;
	struct addrinfo hints;
	struct addrinfo *res = 0;

	if (argc != MAIN_VALID_ARGC) {
		quit(
				"wrong usage, use: stream_client <server_ip/server_name> <server_port>",
				0);
	}

	memset(&hints, 0, sizeof(struct addrinfo));
	hints.ai_family = PF_UNSPEC;
	hints.ai_socktype = SOCK_STREAM;
	if ((getaddrinfo(argv[1], argv[2], &hints, &res)) < 0) {
		quit("failed to get address info", 0);
	}
	/* get the parameters */
	server_ip = ((struct sockaddr_in *) res->ai_addr)->sin_addr;
	server_port = atoi(argv[2]);

	/* create the buffer */
	memset(&buffer, 0, sizeof(char) * IMAGE_SIZE);

	/* run the streaming client as a separate thread */
	if (pthread_create(&thread_c, NULL, streamClient, NULL)) {
		quit("pthread_create client failed.", 1);
	}

	/* run the streaming server as a separate thread */
	if (pthread_create(&thread_s, NULL, streamServer, NULL)) {
		quit("pthread_create server failed.", 1);
	}

	/* show the images recieved by the client */
	showImage();

	/* user has pressed 'escape', terminate the streaming client and the server */
	exit_client = 0;
	exit_server = 0;
	pthread_join(thread_c, NULL);
#ifdef DEBUG
	printf("client joined\n");
#endif
	/* send a signal to the server to end it */
	pthread_kill(thread_s, SIGUSR1);
	pthread_join(thread_s, NULL);
#ifdef DEBUG
	printf("server joined\n");
#endif
	quit("bye", 0);
	return 0;
}

/**
 * show the images recieved by the client in a window with the standard cv GUI
 */
void showImage(void) {
	IplImage * img = CV_CREATE_DEFAULT_IMAGE;
	cvNamedWindow("stream_client", CV_WINDOW_AUTOSIZE);

	printf("Press 'escape' to quit.\n\n");
	while (1) {
		pthread_mutex_lock(&mutexBuffer);
		if (isShowImageReady) {
			img->imageSize = IMAGE_SIZE;
			int bufferWritePosition_own = (bufferWritePosition
					+ BUFFER_FRAME_SIZE - 1) % BUFFER_FRAME_SIZE;
			img->imageData = buffer[bufferWritePosition_own];
			cvShowImage("stream_client", img);
			isShowImageReady = 0;
		}
		pthread_mutex_unlock(&mutexBuffer);
		if ((cvWaitKey(5) & 255) == ESCAPE_KEY_INT) {
#ifdef DEBUG
			printf("ending program..\n");
#endif
			break;
		}
	}
	/* free memory */
	cvReleaseImage(&img);
	cvDestroyWindow("stream_client");
#ifdef DEBUG
	printf("destroyed window\n");
#endif
}

/*############################################ C L I E N T #############################################################*/

/**
 *  This is the streaming client, run as separate thread
 */
void* streamClient(void* arg) {

	struct sockaddr_in client;
	char rcvImageData[230400];

	/* create socket */
	if ((sockClient = socket(PF_INET, SOCK_STREAM, 0)) < 0) {
		quit("socket() failed.", 1);
	}

	/* setup server parameters */
	memset(&client, 0, sizeof(client));
	memset(&rcvImageData, 0, IMAGE_SIZE);

	client.sin_family = AF_INET;
	client.sin_addr.s_addr = server_ip.s_addr;
	client.sin_port = htons(server_port);
#ifdef DEBUG
	printf("ip: %d, port: %d\n", (int) server_ip.s_addr, server_port);
	fflush(stdout);
#endif

	/* connect to server */
	if (connect(sockClient, (struct sockaddr*) &client, sizeof(client)) < 0) {
		quit("connect() failed.", 1);
	}

	/* start receiving images */
	while (exit_client) {
		if (recv(sockClient, rcvImageData, IMAGE_SIZE, MSG_WAITALL) == -1) {
			perror("client: recv failed");
		}
		pthread_mutex_lock(&mutexBuffer);
		bufferWritePosition = (bufferWritePosition + 1) % BUFFER_FRAME_SIZE;
		memcpy(buffer[bufferWritePosition], rcvImageData, IMAGE_SIZE);
		isShowImageReady = 1;
		pthread_mutex_unlock(&mutexBuffer);
		/* cond_newImage = true; */
		pthread_cond_broadcast(&condNewImage);
	}

	return 0;

}
/*############################################ S E R V E R #############################################################*/

/**
 *
 */
void* streamServer(void* arg) {

	struct sockaddr_in server;
	/* open socket */
	if ((sockServ = socket(AF_INET, SOCK_STREAM, 0)) == -1) {
		quit("socket() failed", 1);
	}
	int option = 1;
	setsockopt(sockServ, SOL_SOCKET, SO_REUSEADDR, &option, sizeof(option));

	/* allocate servers socket address memory */
	bzero((char *) &server, sizeof(server));
	memset(&server, 0, sizeof(server));

	/* setup server's IP and port */
	server.sin_family = AF_INET;
	server.sin_addr.s_addr = INADDR_ANY;
	int server_port_try = server_port;
	int tries = 0;
	int success = -1;
	do {
		tries++;
		server_port_try++;
		server.sin_port = htons(server_port_try);
		/* bind the socket */
	} while ((success = bind(sockServ, (struct sockaddr*) &server,
			sizeof(server)) == -1) && (tries < MAX_SOCKET_PORT_TRIES));

	if (success < 0) {
		quit("bind() failed.", 1);
	}

	/* wait for connection */
	if (listen(sockServ, CLIENTSIZE) == -1) {
		quit("listen() failed.", 1);
	}

	struct sigaction sigact;
	/* Setup signal handler for USR1 */
	sigact.sa_handler = rcvServerSignal;
	sigemptyset(&sigact.sa_mask);
	sigact.sa_flags = 0;
	if (sigaction(SIGUSR1, &sigact, NULL) == -1) {
		quit("Error installing signal handler for USR1", 1);
	}

	/* accept a client */
	int clientfd[CLIENTSIZE];
	freeServers = CLIENTSIZE;
	activeClientArrayPosition = 0;
	struct sockaddr_in client_addr;

	socklen_t clientLen;
	pthread_t workingServerThread[CLIENTSIZE];
	bzero(&client_addr, sizeof(client_addr));

	/*---accept a connection (creating a data pipe)---*/
	while (exit_server) {

		activeClientArrayPosition =
				(activeClientArrayPosition + 1) % CLIENTSIZE;
		printf("waiting for connections...\n");
		fflush(stdout);
		clientfd[activeClientArrayPosition] = accept(sockServ,
				(struct sockaddr*) &client_addr, &clientLen);
		pthread_mutex_lock(&mutexFreeServers);
		freeServers--;
		pthread_mutex_unlock(&mutexFreeServers);
		if (freeServers < 0) {
			close(clientfd[activeClientArrayPosition]);
			pthread_mutex_lock(&mutexFreeServers);
			freeServers ++;
			pthread_mutex_unlock(&mutexFreeServers);
		} else {
			if (clientfd < 0) {
#ifdef DEBUG
				perror("accepted no client\n");
#endif
			} else {
				printf("%s:%d connected on fd:%d\n",
						inet_ntoa(client_addr.sin_addr),
						ntohs(client_addr.sin_port),
						clientfd[activeClientArrayPosition]);
				pthread_create(&workingServerThread[activeClientArrayPosition],
				NULL, workingServer, &clientfd[activeClientArrayPosition]);
				pthread_detach(workingServerThread[activeClientArrayPosition]);
			}
		}
	}
	/* close the server socket */
	close(sockServ);
	return 0;
}

/**
 * empty method for responding to the signal from main that exits the accept of the server
 */
void rcvServerSignal(int sig) {
}

/**
 *
 */
void * workingServer(void* sockfd) {
	int clientfd = *((int *) sockfd);
	int bytes;
	IplImage * readImage = CV_CREATE_DEFAULT_IMAGE;
	int bufferWritePosition_own = (bufferWritePosition + BUFFER_FRAME_SIZE - 1)
			% BUFFER_FRAME_SIZE;
	printf("w%d\n", clientfd);

	while (1) {
		readImage->imageSize = IMAGE_SIZE;
		/* get the current buffer index (within the mutex) and return the pointer to it */
		pthread_mutex_lock(&mutexBuffer);
		// wait on condition
		pthread_cond_wait(&condNewImage, &mutexBuffer);
		bufferWritePosition_own = (bufferWritePosition_own + 1)
				% BUFFER_FRAME_SIZE;
		pthread_mutex_unlock(&mutexBuffer);
		memcpy(readImage->imageData, buffer[bufferWritePosition_own],
		IMAGE_SIZE);
		bytes = send(clientfd, readImage->imageData, readImage->imageSize,
		MSG_NOSIGNAL);
		if (bytes < 0) {
			printf("broken pipe on fd: " + clientfd);
			break;
		}
	}
	cvReleaseImage(&readImage);
	close(clientfd);
	pthread_mutex_lock(&mutexFreeServers);
	freeServers ++;
	pthread_mutex_unlock(&mutexFreeServers);
	pthread_exit(0);
	return 0;
}

/**
 * This function provides a way to exit nicely from the system
 */
void quit(char* msg, int retval) {
	if (retval == 0) {
		fprintf(stdout, (msg == NULL ? "" : msg), msg);
		fprintf(stdout, "\n");
	} else {
		fprintf(stderr, (msg == NULL ? "" : msg), msg);
		fprintf(stderr, "\n");
	}
	if (sockClient) {
		close(sockClient);
		close(sockServ);

		printf("server ended.\n");
	}
	/* notify threads to end */
	if (sockClient && sockServ) {
		exit_client = 0;
		exit_server = 0;
	}

	pthread_mutex_destroy(&mutexBuffer);
	exit(retval);
}
