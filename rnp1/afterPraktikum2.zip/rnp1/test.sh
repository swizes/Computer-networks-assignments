#!/bin/bash
# shell script to test functionality of the client/server
# Jannik Iacobi, Cumhur Güner
# 03.11.14
usage()
{
	echo "usage: $0 <hostname> <hostport>"
}

if [ $# <= 2 ]; then
    usage
    exit 1
fi

# test multiple connections that end directly
cd Debug
for (( i=1;$i<=50;i=$i+1 ))
do
    ./rnp1 $1 $2 &
    sleep 0.2
    pkill -f "rnp1 $1 $2"
done
exit 0
