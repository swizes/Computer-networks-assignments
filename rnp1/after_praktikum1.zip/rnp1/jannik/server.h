/*
 * server.h
 *
 *  Created on: 23 Oct 2014
 *      Author: abo278
 */

#ifndef SERVER_H_
#define SERVER_H_

#include "main.h"

#define SERVER_QUEUE_LEN 5

#define SERVER_LOOP_COND 1

#endif /* SERVER_H_ */
