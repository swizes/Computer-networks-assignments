/*
 * client.h
 *
 *  Created on: 23 Oct 2014
 *      Author: abo278
 */

#ifndef CLIENT_H_
#define CLIENT_H_

#include "main.h"

/* OpenCV  */
#include <opencv/cv.h>
#include <opencv/highgui.h>


#endif /* CLIENT_H_ */
